from django.urls import path
from.import views
from django.contrib.auth import views as auth_views
urlpatterns=[
    path('',views.home, name='home'),
    path('register/', views.register, name='register'),
    path('login/', views.user_login, name='login'),
    path('logout/', views.user_logout, name='logout'),

     path('password-reset/',auth_views.PasswordResetView.as_view(),name='password_reset'),
   path('password-reset/done',auth_views.PasswordResetDoneView.as_view(),name='password_reset_done'),
   path('reset/<uidb64>/<token>/',auth_views.PasswordResetConfirmView.as_view(),name='password_reset_comfirm'),

      path('reset/done',auth_views.PasswordResetCompleteView.as_view(),name='password_reset_complete'),







    
path('student_details',views.student_details, name='student_details'),
path('mca102/',views.mca102, name='mca102'),
path('mca103/',views.mca103, name='mca103'),
path('mca104/',views.mca104, name='mca104'),
path('mca105/',views.mca105, name='mca105'),
path('mca106/',views.mca106, name='mca106'),
path('mca107/',views.mca107, name='mca107'),
path('mca108/',views.mca108, name='mca108'),
path('mca201/',views.mca201, name='mca201'),
path('mca202/',views.mca202, name='mca202'),
path('mca203/',views.mca203, name='mca203'),
path('mca204/',views.mca204, name='mca204'),
path('mca205/',views.mca205, name='mca205'),
path('mca206/',views.mca206, name='mca206'),
path('mca207/',views.mca207, name='mca207'),
path('mca208/',views.mca208, name='mca208'),
path('mca209/',views.mca209, name='mca209'),
path('mca301/',views.mca301, name='mca301'),
path('mca302/',views.mca302, name='mca302'),
path('mca303/',views.mca303, name='mca303'),
path('mca304/',views.mca304, name='mca304'),
path('mca305/',views.mca305, name='mca305'),
path('mca307/',views.mca307, name='mca307'),
path('mca308/',views.mca308, name='mca308'),
path('mca309/',views.mca309, name='mca309'),
path('mca310/',views.mca310, name='mca310'),
path('mca401/',views.mca401, name='mca401'),
path('mca402/',views.mca402, name='mca402'),
path('mca403/',views.mca403, name='mca403'),
path('m/',views.m, name='m'),
path('n/',views.m, name='n'),
path('o/',views.m, name='o'),
path('p/',views.m, name='p'),
    
]
